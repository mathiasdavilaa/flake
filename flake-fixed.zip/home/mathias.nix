{ config, pkgs, ... }:

{
  imports = [
    ../modules/features/zed
    ../modules/features/macro
    ../modules/features/fastfetch
    ../modules/features/kitty
    ../modules/features/ghostty
    ../modules/features/mango
  ];

  home.username = "mathias";
  home.homeDirectory = "/home/mathias";
  home.stateVersion = "24.05";

  home.pointerCursor = {
    package = pkgs.bibata-cursors;
    name = "Bibata-Modern-Ice";
    size = 20;

    gtk.enable = true;
    x11.enable = true;
  };

  programs.fish = {
    enable = true;

    interactiveShellInit = ''
      set -g fish_greeting
      fastfetch
    '';

    shellAliases = {
      ncfg = "zeditor ~/flake";
      nrs = "cd ~/flake && git add . && sudo nixos-rebuild switch --impure --flake ~/flake#laptop";
      nru = "nix flake update --flake ~/flake";
      ff = "fastfetch";
    };
  };

  programs.home-manager.enable = true;
}
